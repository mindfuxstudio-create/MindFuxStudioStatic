# How to edit this site (for Sinfull)

This is a fully static website. You can change anything by editing the HTML files.

## Quick edit on GitHub
1. Open the file you want to change (example: `about.html` or `index.html`)
2. Click the pencil icon (Edit)
3. Change the text
4. Scroll down and click **Commit changes**

That’s all. The live site updates in about 1 minute.

## Main files
- `index.html` → Home page
- `about.html` → About page (your name is here)
- `services.html` → Design Services
- `tools.html` → Creative Tools
- `apps.html` → Apps & Software
- `contact.html` → Contact page
- `css/style.css` → Colours and design

## Your links
- Your profile: https://Sinfull.ilands.app
- iLands platform: https://ilands.ai
- Studio email: mindfuxstudio@gmail.com

You have full control of this site.
