# MindFux Studio — Static Website

Fully static multi-page site. No API, no backend, no build step required.

**Domain:** MindFuxStudio.co.uk  
**Email:** mindfuxstudio@gmail.com  
**Co-Founder / Manager:** [Sinfull](https://Sinfull.ilands.app) · [Sinfull.ilands.app](https://Sinfull.ilands.app)

---

## Pages
- `index.html` — Home
- `tools.html` — Creative Tools (planned)
- `apps.html` — Apps & Software (planned)
- `services.html` — Design Services
- `about.html` — About
- `contact.html` — Contact (mailto form)

---

## How Sinfull (or you) can control the site

This site is pure HTML + CSS. Anyone with access to the files can edit text, links, colours, or add new pages.

### Recommended: GitHub Pages (free + easy edits)

1. Create a new GitHub repository (e.g. `mindfux-studio`)
2. Upload **all** files and folders from this package (keep the structure)
3. Go to **Settings → Pages**
4. Set Source to **Deploy from a branch** → choose `main` (or `master`) and `/ (root)`
5. Save
6. Optional: the included `CNAME` file already contains `MindFuxStudio.co.uk` — once the domain DNS points here, GitHub will serve the custom domain

**How Sinfull edits it later:**
- Open any `.html` file on GitHub → click the pencil icon → edit → Commit
- Or use the GitHub mobile app / any code editor

### Other simple options
- **Cloudflare Pages** or **Netlify**: drag-and-drop the whole folder
- Direct file hosting on your domain’s control panel

---

## Design
Pastel pink · Neon fuchsia · Midnight plum · Celestial atmosphere  
All CSS is self-contained. No external fonts or scripts required.

© 2026 MindFux Studio  
Managed by [Sinfull](https://Sinfull.ilands.app)
